package com.gaoyg.monkeyzicloud.commom.core.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.codec.Base64;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * @author: 高yg
 * @date: 2018/7/28 20:02
 * @qq:854152531@qq.com
 * @blog http://www.monkeyzi.xin
 * @description:获取request
 */
@Slf4j
public class RequestUtils {


    public static String getAuthHeader(HttpServletRequest request){
        String authHeader=request.getHeader(HttpHeaders.AUTHORIZATION);
        if (StringUtils.isBlank(authHeader)){
            return null;
        }
        return authHeader;
    }

    public static String[] extractAndDecodeHeader(String header) throws IOException {
        byte[] base64Token = header.substring(6).getBytes("UTF-8");
        byte[] decoded;
        try {
           decoded= Base64.decode(base64Token);
        }catch (IllegalArgumentException e){
            throw new BadCredentialsException("token解码失败");
        }
        String token=new String(decoded,"UTF-8");
        int  deim=token.indexOf(":");
        if (deim==-1){
            throw new BadCredentialsException("非法的token");
        }
        return new String[]{token.substring(0, deim), token.substring(deim + 1)};
    }
}
