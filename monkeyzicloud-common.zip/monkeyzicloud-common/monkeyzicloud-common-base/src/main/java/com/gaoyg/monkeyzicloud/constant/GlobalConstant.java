package com.gaoyg.monkeyzicloud.constant;

/**
 * @author: 高yg
 * @date: 2018/7/21 00:18
 * @qq:854152531@qq.com
 * @blog http://www.monkeyzi.xin
 * @description:
 */
public interface GlobalConstant {
     String MONKEYZI_PREFIX="monkeyzicloud";


     final  class  sys{
          public sys(){
          }
          /**
           * 全局用户名
           */
          public static final String TOKEN_AUTH_USER = "CURRENT_AUTH_USER";
     }
}
